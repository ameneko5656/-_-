import bpy

# アドオンの基本情報
bl_info = {
    "name": "布で覆う",
    "author": "あめねこ",
    "version": (1, 0, 0),
    "blender": (3, 3, 0),
    "location": "3Dビューポート > サイドバー",
    "description": "布で覆うアドオン",
    "warning": "",
    "support": "COMMUNITY",
    "doc_url": "",
    "tracker_url": "",
    "category": "Sample"
}

# プロパティグループ
class CoverWithClothProperties(bpy.types.PropertyGroup):
    size: bpy.props.FloatProperty(
        name="布のサイズ",
        description="布の基本サイズ",
        default=4.0,
        min=0.1,
        max=10.0
    )
    number_cuts: bpy.props.IntProperty(
        name="布の分割数",
        description="布の分割数",
        default=30,
        min=1,
        max=100
    )
    pin_stiffness: bpy.props.FloatProperty(
        name="ピン剛性",
        description="ピンの剛性",
        default=1.0,
        min=0.1,
        max=10.0
    )
    object_type: bpy.props.EnumProperty(
        name="衝突オブジェクト",
        description="布の下に配置するオブジェクトの種類",
        items=[
            ('SPHERE', "球", "UV Sphere"),
            ('CUBE', "立方体", "Cube"),
            ('CONE', "円錐", "Cone"),
            ('CYLINDER', "円柱", "Cylinder"),
            ('TORUS', "トーラス", "Torus")
        ],
        default='SPHERE'
    )

# 布の生成オペレーター
class SAMPLE_OT_CoverWithCloth(bpy.types.Operator):
    bl_idname = "sample.create_cover_with_cloth"
    bl_label = "布で覆う作成"
    bl_description = "布と衝突オブジェクトを生成します"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # プロパティを取得
        props = context.scene.CoverWithCloth_props

        # 既存のオブジェクトを削除
        for obj in bpy.data.objects:
            if obj.name in {"Cloth", "CollisionObject"}:
                bpy.data.objects.remove(obj, do_unlink=True)

        # 布（平面）を生成
        bpy.ops.mesh.primitive_plane_add(size=props.size, location=(0, 0, 1))
        plane = bpy.context.active_object
        plane.name = "Cloth"

        # 布の分割
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.subdivide(number_cuts=props.number_cuts)
        bpy.ops.object.mode_set(mode='OBJECT')

        # クロスモディファイアの設定
        cloth_mod = plane.modifiers.new("Cloth", 'CLOTH')
        cloth_mod.settings.use_dynamic_mesh = True
        cloth_mod.settings.pin_stiffness = props.pin_stiffness

        # ピン用の頂点グループを作成
        pin_group = plane.vertex_groups.new(name="PinGroup")
        for vertex in plane.data.vertices:
            if vertex.co.z > 0.95 * props.size:  # 布のサイズに基づいて設定
                pin_group.add([vertex.index], 1.0, 'REPLACE')

        # クロスモディファイアに頂点グループを設定
        cloth_mod.settings.vertex_group_mass = "PinGroup"

        # 衝突オブジェクトを生成
        if props.object_type == 'SPHERE':
            bpy.ops.mesh.primitive_uv_sphere_add(radius=props.size / 4, location=(0, 0, -1))
        elif props.object_type == 'CUBE':
            bpy.ops.mesh.primitive_cube_add(size=props.size / 4, location=(0, 0, -1))
        elif props.object_type == 'CONE':
            bpy.ops.mesh.primitive_cone_add(radius1=props.size / 4, depth=props.size / 2, location=(0, 0, -1))
        elif props.object_type == 'CYLINDER':
            bpy.ops.mesh.primitive_cylinder_add(radius=props.size / 4, depth=props.size / 2, location=(0, 0, -1))
        elif props.object_type == 'TORUS':
            bpy.ops.mesh.primitive_torus_add(major_radius=props.size / 4, minor_radius=props.size / 8, location=(0, 0, -1))
        
        collision_object = bpy.context.active_object
        collision_object.name = "CollisionObject"

        # 衝突モディファイアの設定
        collision_object.modifiers.new("Collision", 'COLLISION')

        return {'FINISHED'}

# シミュレーション開始オペレーター
class SAMPLE_OT_StartSimulation(bpy.types.Operator):
    bl_idname = "sample.start_simulation"
    bl_label = "シミュレーション開始"
    bl_description = "布のシミュレーションを開始します"

    def execute(self, context):
        bpy.context.scene.frame_set(1)  # フレームをリセット
        bpy.ops.screen.animation_play()  # アニメーションを再生
        return {'FINISHED'}

# シミュレーション停止オペレーター
class SAMPLE_OT_StopSimulation(bpy.types.Operator):
    bl_idname = "sample.stop_simulation"
    bl_label = "シミュレーション停止"
    bl_description = "布のシミュレーションを停止します"

    def execute(self, context):
        bpy.ops.screen.animation_cancel(restore_frame=False)  # アニメーションを停止
        return {'FINISHED'}

# パネル
class SAMPLE_PT_CoverWithCloth(bpy.types.Panel):
    bl_label = "布で覆う"
    bl_idname = "SAMPLE_PT_CoverWithCloth"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "布で覆う"

    def draw(self, context):
        layout = self.layout
        props = context.scene.CoverWithCloth_props

        layout.label(text="布の設定")
        layout.prop(props, "size", text="布のサイズ")
        layout.prop(props, "number_cuts", text="布の分割数")
        layout.prop(props, "pin_stiffness", text="ピン剛性")
        layout.prop(props, "object_type", text="衝突オブジェクト")
        layout.operator(SAMPLE_OT_CoverWithCloth.bl_idname, text="布で覆う")
        layout.operator(SAMPLE_OT_StartSimulation.bl_idname, text="シミュレーション開始")
        layout.operator(SAMPLE_OT_StopSimulation.bl_idname, text="シミュレーション停止")

# クラス登録
classes = (
    CoverWithClothProperties,
    SAMPLE_OT_CoverWithCloth,
    SAMPLE_OT_StartSimulation,
    SAMPLE_OT_StopSimulation,
    SAMPLE_PT_CoverWithCloth,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.CoverWithCloth_props = bpy.props.PointerProperty(type=CoverWithClothProperties)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.CoverWithCloth_props

if __name__ == "__main__":
    register()
