import bpy

# シーンの設定
bl_info = {
    "name": "ソフトボディ: 豆腐",
    "author": "あめねこ",
    "version": (1, 0, 0),
    "blender": (3, 3, 0),
    "location": "3Dビューポート > サイドバー",
    "description": "豆腐を作るアドオン",
    "warning": "",
    "support": "COMMUNITY",
    "doc_url": "",
    "tracker_url": "",
    "category": "Sample"
}


# プロパティグループ
class SoftBodyTofuProperties(bpy.types.PropertyGroup):
    size: bpy.props.FloatProperty(
        name="豆腐のサイズ",
        description="豆腐の基本サイズ",
        default=1.0,
        min=0.1,
        max=10.0
    )
    mass: bpy.props.FloatProperty(
        name="質量 (Mass)",
        description="豆腐の質量",
        default=1.0,
        min=0.1,
        max=10.0
    )
    bend: bpy.props.FloatProperty(
        name="曲がりやすさ (Bend)",
        description="豆腐の曲がりやすさ",
        default=0.5,
        min=0.0,
        max=5.0
    )
    push: bpy.props.FloatProperty(
        name="押し返す力 (Push)",
        description="豆腐の押し返す力",
        default=0.3,
        min=0.0,
        max=5.0
    )
    pull: bpy.props.FloatProperty(
        name="引っ張る力 (Pull)",
        description="豆腐の引っ張る力",
        default=0.3,
        min=0.0,
        max=5.0
    )
    damping: bpy.props.FloatProperty(
        name="減衰 (Damping)",
        description="豆腐の振動の減衰率",
        default=0.5,
        min=0.0,
        max=1.0
    )


# オペレーター
class SAMPLE_OT_CreateSoftBodyTofu(bpy.types.Operator):
    bl_idname = "sample.create_softbody_tofu"
    bl_label = "ソフトボディの豆腐を制作"
    bl_description = "ソフトボディの豆腐を作成します"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.softbody_tofu_props

        # 既存の豆腐や平面オブジェクトを削除
        bpy.ops.object.select_all(action='DESELECT')
        for obj in bpy.data.objects:
            if obj.name.startswith("SoftBodyTofu") or obj.name == "CollisionPlane":
                obj.select_set(True)
        bpy.ops.object.delete()

        # ソフトボディ用の立方体を追加
        bpy.ops.mesh.primitive_cube_add(size=props.size, location=(0, 0, 3))
        softbody_obj = bpy.context.active_object
        softbody_obj.name = "SoftBodyTofu"

        # ソフトボディモディファイアを追加
        softbody_mod = softbody_obj.modifiers.new(name="Softbody", type='SOFT_BODY')
        softbody_mod.settings.mass = props.mass
        softbody_mod.settings.bend = props.bend
        softbody_mod.settings.push = props.push
        softbody_mod.settings.pull = props.pull
        softbody_mod.settings.damping = props.damping
        
        # Goal設定を無効化（自由落下を可能にする）
        softbody_mod.settings.use_goal = False  # 固定を解除

        # 衝突用の平面を追加
        bpy.ops.mesh.primitive_plane_add(size=10, location=(0, 0, 0))
        collision_obj = bpy.context.active_object
        collision_obj.name = "CollisionPlane"
        collision_obj.modifiers.new(name="Collision", type='COLLISION')
        
         # アニメーションを再生
        bpy.ops.screen.animation_play()
        
        self.report({'INFO'}, "豆腐を作成しました！")
        return {'FINISHED'}


# パネル
class SAMPLE_PT_SoftBodyTofuPanel(bpy.types.Panel):
    bl_label = "ソフトボディ豆腐"
    bl_idname = "SAMPLE_PT_softbody_tofu_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "豆腐"

    def draw(self, context):
        layout = self.layout
        props = context.scene.softbody_tofu_props

        layout.label(text="豆腐のプロパティ")
        layout.prop(props, "size")
        layout.prop(props, "mass")
        layout.prop(props, "bend")
        layout.prop(props, "push")
        layout.prop(props, "pull")
        layout.prop(props, "damping")
        layout.operator(SAMPLE_OT_CreateSoftBodyTofu.bl_idname, text="豆腐を作成")


# アドオン登録/解除
classes = [
          SoftBodyTofuProperties, 
          SAMPLE_OT_CreateSoftBodyTofu, 
          SAMPLE_PT_SoftBodyTofuPanel
          ]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.softbody_tofu_props = bpy.props.PointerProperty(type=SoftBodyTofuProperties)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.softbody_tofu_props


if __name__ == "__main__":
    register()
