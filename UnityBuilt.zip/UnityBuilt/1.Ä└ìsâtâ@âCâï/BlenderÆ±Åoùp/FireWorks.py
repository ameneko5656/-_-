import bpy

bl_info = {
    "name": "花火みたいなの",
    "author": "あめねこ",
    "version": (1, 0, 0),
    "blender": (3, 3, 0),
    "location": "3Dビューポート > サイドバー",
    "description": "花火みたいなのをつくるアドオン",
    "category": "Object"
}

class FireWorksProperties(bpy.types.PropertyGroup):
    size: bpy.props.FloatProperty(
        name="花火のサイズ",
        description="花火のサイズ",
        default=1.0,
        min=0.1,
        max=10.0
    )
    count: bpy.props.IntProperty(
        name="パーティクル数",
        description="生成する花火の粒子数",
        default=2000,
        min=1,
        max=10000
    )
    mass: bpy.props.FloatProperty(
        name="粒子質量",
        description="花火粒子の質量",
        default=0.1,
        min=0.01,
        max=2.0
    )
    normal_factor: bpy.props.FloatProperty(
        name="速度倍率",
        description="花火粒子の速度倍率",
        default=10.0,
        min=1.0,
        max=20.0
    )

class SAMPLE_OT_FireWorks(bpy.types.Operator):
    bl_idname = "sample.create_fire_works"
    bl_label = "花火を作成"
    bl_description = "花火を生成します"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.FireWorks_props

        for obj in bpy.data.objects:
            if obj.name in {"Sphere"}:
                bpy.data.objects.remove(obj, do_unlink=True)

        bpy.ops.mesh.primitive_uv_sphere_add(radius=props.size, location=(0, 0, 1))
        sphere = bpy.context.active_object
        sphere.name = "Sphere"

        bpy.ops.object.particle_system_add()
        particle_system = sphere.particle_systems[0]
        particle_settings = particle_system.settings

        particle_settings.type = 'EMITTER'
        particle_settings.count = props.count
        particle_settings.frame_start = 1
        particle_settings.frame_end = 10
        particle_settings.lifetime = 50
        particle_settings.emit_from = 'FACE'
        particle_settings.physics_type = 'NEWTON'
        particle_settings.mass = props.mass
        particle_settings.normal_factor = props.normal_factor

        explode_mod = sphere.modifiers.new(name="Explode", type="EXPLODE")
        explode_mod.use_edge_cut = True
        explode_mod.show_unborn = False
        explode_mod.show_alive = True
        explode_mod.show_dead = True

        return {'FINISHED'}
# シミュレーション開始オペレーター
class SAMPLE_OT_StartSimulation(bpy.types.Operator):
    bl_idname = "sample.start_simulation"
    bl_label = "シミュレーション開始"
    bl_description = "布のシミュレーションを開始します"

    def execute(self, context):
        bpy.context.scene.frame_set(1)  # フレームをリセット
        bpy.ops.screen.animation_play()  # アニメーションを再生
        return {'FINISHED'}

# シミュレーション停止オペレーター
class SAMPLE_OT_StopSimulation(bpy.types.Operator):
    bl_idname = "sample.stop_simulation"
    bl_label = "シミュレーション停止"
    bl_description = "布のシミュレーションを停止します"

    def execute(self, context):
        bpy.ops.screen.animation_cancel(restore_frame=False)  # アニメーションを停止
        return {'FINISHED'}
    
class SAMPLE_PT_FireWorks(bpy.types.Panel):
    bl_label = "花火を生成する"
    bl_idname = "SAMPLE_PT_FireWorks"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "花火"

    def draw(self, context):
        layout = self.layout
        props = context.scene.FireWorks_props

        layout.label(text="花火の設定")
        layout.prop(props, "size")
        layout.prop(props, "count")
        layout.prop(props, "mass")
        layout.prop(props, "normal_factor")
        layout.operator(SAMPLE_OT_FireWorks.bl_idname, text="花火を生成")
        layout.operator(SAMPLE_OT_StartSimulation.bl_idname, text="シミュレーション開始")
        layout.operator(SAMPLE_OT_StopSimulation.bl_idname, text="シミュレーション停止")

classes = (
    FireWorksProperties,
    SAMPLE_OT_FireWorks,
    SAMPLE_PT_FireWorks,
    SAMPLE_OT_StartSimulation,
    SAMPLE_OT_StopSimulation,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.FireWorks_props = bpy.props.PointerProperty(type=FireWorksProperties)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.FireWorks_props

if __name__ == "__main__":
    register()
